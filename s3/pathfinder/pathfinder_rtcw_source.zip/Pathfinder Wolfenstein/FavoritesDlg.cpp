// FavoritesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Pathfinder.h"
#include "FavoritesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFavoritesDlg dialog

enum EFavoritesCol
{
  fc_name, fc_ip, fc_pwd,
  fc_numCols
};

CFavoritesDlg::CFavoritesDlg(CWnd* pParent /*=NULL*/)
  : CDialog(CFavoritesDlg::IDD, pParent),
    m_minSize(0, 0)
{
  //{{AFX_DATA_INIT(CFavoritesDlg)
    // NOTE: the ClassWizard will add member initialization here
  //}}AFX_DATA_INIT
}

void CFavoritesDlg::DoDataExchange(CDataExchange* pDX)
{
  CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CFavoritesDlg)
    // NOTE: the ClassWizard will add DDX and DDV calls here
  //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFavoritesDlg, CDialog)
  //{{AFX_MSG_MAP(CFavoritesDlg)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFavoritesDlg message handlers

BOOL CFavoritesDlg::OnInitDialog()
{
  CDialog::OnInitDialog();

  SetIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME), TRUE);    // Set small icon

	CRect rect;
  GetWindowRect(rect);
  m_minSize = rect.Size();

  m_favorites.SubclassDlgItem(IDC_FAVORITES, this);
  m_favorites.BeginDefinition(fc_numCols);
  m_favorites.SetColDef(fc_name, CStringCol(), "Name", 150);
  m_favorites.SetColDef(fc_ip, CStringCol(), "Ip", 128);
  m_favorites.SetColDef(fc_pwd, CStringCol(), "Password");
  m_favorites.EndDefinition();
	m_favorites.EnableEdit();

	m_arranger.Create(this);
	m_arranger.Add(m_favorites, ADH_GROW|ADV_GROW);
	m_arranger.Add(IDC_ADD, ADV_MOVE);
	m_arranger.Add(IDC_DELETE, ADV_MOVE);
	m_arranger.Add(IDOK, ADH_MOVE|ADV_MOVE);
	m_arranger.Add(IDCANCEL, ADH_MOVE|ADV_MOVE);

  LoadFavorites();

  CRegistry reg;
  reg.SetRootKey(HKEY_CURRENT_USER);
  reg.SetKey("Software\\Pathfinder", true);

  // TDM Einstellung aus Registry lesen
  CWordArray prop;
  HKEY hKey;
  DWORD type, size;

  m_favorites.GetSerializedProperties(prop); // setzt die Gr��e von prop richtig!
  size = prop.GetSize() * 2;
	::RegOpenKeyEx(reg.GetRootKey(), reg.GetCurrentPath(), 0, KEY_READ, &hKey);
  ::RegQueryValueEx(hKey, "TDM_Favorites", 0, &type, LPBYTE(prop.GetData()), &size);
  ::RegCloseKey(hKey);
  m_favorites.SetSerializedProperties(prop);
  m_favorites.Refresh();

  CRect lastPos;
  if (reg.ReadRect("LastPosFavorites", &lastPos) && lastPos.Width() > m_minSize.x)
  {
    MoveWindow(lastPos);
    CenterWindow();
  }  

  return TRUE;  // return TRUE unless you set the focus to a control
                // EXCEPTION: OCX Property Pages should return FALSE
}

void CFavoritesDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
  CRegistry reg;
  reg.SetRootKey(HKEY_CURRENT_USER);
  reg.SetKey("Software\\Pathfinder", true);

   // TDM Einstellung in Registry sichern (Key muss existieren)
  CWordArray prop;
  HKEY hKey;

  m_favorites.GetSerializedProperties(prop);
	::RegOpenKeyEx(reg.GetRootKey(), reg.GetCurrentPath(), 0, KEY_ALL_ACCESS, &hKey);
  ::RegSetValueEx(hKey, "TDM_Favorites", 0, REG_BINARY, reinterpret_cast<unsigned char*>(prop.GetData()), prop.GetSize() * 2);
  ::RegCloseKey(hKey);
  
  CRect rect;
  GetWindowRect(rect);
  rect.NormalizeRect();
  reg.WriteRect("LastPosFavorites", &rect);
}

void CFavoritesDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	m_arranger.Arrange();
}

void CFavoritesDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);

  if (m_minSize.x && m_minSize.y)	lpMMI->ptMinTrackSize = m_minSize;
}


void CFavoritesDlg::OnAdd() 
{
	CRowData& row = m_favorites.AddRow();
  row[fc_name] = "New Server";
  row[fc_ip] = "127.0.0.1:27960";
  m_favorites.SetCurSel(m_favorites.GetNumRows() - 1);
  m_favorites.Refresh();
}

void CFavoritesDlg::SaveFavorites()
{
	CStdioFile file("favorites.dat", CFile::modeWrite|CFile::modeCreate);
  
	for (int i = m_favorites.GetNumRows(); i--;)
	{
		file.WriteString
		(
			m_favorites[i][fc_ip].AsString()   + "\t" +
      m_favorites[i][fc_name].AsString() + "\t" +
			m_favorites[i][fc_pwd].AsString()  + "\n"
		);
	}
}

void CFavoritesDlg::LoadFavorites()
{
	CStdioFile file;
	
	if (file.Open("favorites.dat", CFile::modeRead))
  {
    for (CExString s; file.ReadString(s);)
    {
      CRowData& row = m_favorites.InsertRow(0);
      row[fc_ip]   = s.GetField('\t', 0);
      row[fc_name] = s.GetField('\t', 1);
      row[fc_pwd]  = s.GetField('\t', 2);
    }
  }
  m_favorites.Refresh();
}

void CFavoritesDlg::OnOK() 
{
  m_favorites.EndEdit();

  // Validierung
 	for (int i = m_favorites.GetNumRows(); i--;)
	{
    CRowData& row = m_favorites[i];
    
    CExString name = row[fc_name].AsString();
    name.Replace('\t', ' ');
    name.Trim();
    row[fc_name] = name;

    if (!CSockAddr(row[fc_ip].AsString()).IsValid())
    {
      m_favorites.SetCurSel(i);
      m_favorites.BeginEdit(i, fc_ip);
      m_favorites.Refresh();
      AfxMessageBox("Invalid IP address.", MB_ICONERROR);
      return;
    }

    row[fc_ip] = CSockAddr(row[fc_ip].AsString()).GetDottedDecimalWithPort2();
 
    CExString pwd = row[fc_pwd].AsString();
    pwd.Replace('\t', ' ');
    pwd.Trim();
    row[fc_pwd] = pwd;
  }

	SaveFavorites();

	CDialog::OnOK();
}

void CFavoritesDlg::OnDelete() 
{
  m_favorites.CancelEdit();

	int iRow = m_favorites.GetCurSel();
  if (m_favorites.IsRowValid(iRow))
  {
    m_favorites.DeleteRow(iRow);
    m_favorites.Refresh();
  }
}

