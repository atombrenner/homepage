#if !defined(AFX_FAVORITESDLG_H__4622C8C3_79F9_11D5_AF21_00E07D978BAB__INCLUDED_)
#define AFX_FAVORITESDLG_H__4622C8C3_79F9_11D5_AF21_00E07D978BAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FavoritesDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFavoritesDlg dialog

class CFavoritesDlg : public CDialog
{
// Construction
public:
	CFavoritesDlg(CWnd* pParent = NULL);   // standard constructor

	CTableCtrl m_favorites;
	CArranger  m_arranger;
	CPoint     m_minSize;

	void LoadFavorites();
	void SaveFavorites();

// Dialog Data
	//{{AFX_DATA(CFavoritesDlg)
	enum { IDD = IDD_FAVORITES };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFavoritesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFavoritesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnAdd();
	virtual void OnOK();
	afx_msg void OnDelete();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FAVORITESDLG_H__4622C8C3_79F9_11D5_AF21_00E07D978BAB__INCLUDED_)
