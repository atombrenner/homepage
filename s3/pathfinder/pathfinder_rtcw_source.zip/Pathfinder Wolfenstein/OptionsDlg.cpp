// OptionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Pathfinder.h"
#include "OptionsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog


COptionsDlg::COptionsDlg(CRegistry& reg)
	: CDialog(COptionsDlg::IDD, NULL), m_reg(reg)
{
	//{{AFX_DATA_INIT(COptionsDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void COptionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionsDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionsDlg, CDialog)
	//{{AFX_MSG_MAP(COptionsDlg)
	ON_BN_CLICKED(IDC_REQUERY_SERVER_DATA, OnRequeryServerData)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg message handlers

void COptionsDlg::OnRequeryServerData() 
{
	AfxMessageBox("To reduce lag, it is strongly recommended to also check the 'Close after joining' option when checking this option!");
}

void COptionsDlg::OnOK() 
{
  m_reg.WriteInt("AutoClose", IsDlgButtonChecked(IDC_CLOSE_AFTER_JOINING));
  m_reg.WriteInt("AutoRequery", IsDlgButtonChecked(IDC_REQUERY_SERVER_DATA));
  
  int StartupQuery = 0;
  if (IsDlgButtonChecked(IDC_QUERY_FAVORITES)) StartupQuery = 1;
  if (IsDlgButtonChecked(IDC_QUERY_MASTER)) StartupQuery = 2;
  m_reg.WriteInt("StartupQuery", StartupQuery);
	CDialog::OnOK();
}

BOOL COptionsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
  CheckDlgButton(IDC_CLOSE_AFTER_JOINING, m_reg.ReadInt("AutoClose", 1));
  CheckDlgButton(IDC_REQUERY_SERVER_DATA, m_reg.ReadInt("AutoRequery", 0));

  switch (m_reg.ReadInt("StartupQuery", 0))
  {
  case 0: CheckDlgButton(IDC_QUERY_NOTHING, 1); break;
  case 1: CheckDlgButton(IDC_QUERY_FAVORITES, 1); break;
  case 2: CheckDlgButton(IDC_QUERY_MASTER, 1); break;
  default: break;
  }
	
	return TRUE;  
}
