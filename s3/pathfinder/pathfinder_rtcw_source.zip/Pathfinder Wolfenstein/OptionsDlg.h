#if !defined(AFX_OPTIONSDLG_H__6A3D4A6E_631A_4C5A_A8D2_C97E5BEC9536__INCLUDED_)
#define AFX_OPTIONSDLG_H__6A3D4A6E_631A_4C5A_A8D2_C97E5BEC9536__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptionsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog

class COptionsDlg : public CDialog
{
// Construction
public:
	COptionsDlg(CRegistry& reg);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COptionsDlg)
	enum { IDD = IDD_OPTIONS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

  CRegistry& m_reg;

	// Generated message map functions
	//{{AFX_MSG(COptionsDlg)
	afx_msg void OnRequeryServerData();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONSDLG_H__6A3D4A6E_631A_4C5A_A8D2_C97E5BEC9536__INCLUDED_)
