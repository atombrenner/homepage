/****************************************************************************\
 Datei  : Scan.cpp
 Projekt: Pathfinder
 Inhalt : Helpers to parse Server data
 Datum  : 17.12.2000
 Autor  : Christian Rodemeyer
 Hinweis: 
 Stempel: $Modtime: $, $Author: $, $NoKeywords: $ 
\****************************************************************************/

#include "StdAfx.h"
#include "Scan.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString ScanString(const char*& pc)
{                                        
  // Terminiert durch \ oder \n
  // \ kann in Anf�hrunsgzeichen stehen
  CString s;

  bool bQuoted = false;
  while (*pc && *pc != '\n' && (*pc != '\\' || bQuoted))
  {  
    if      (*pc == '"') bQuoted = !bQuoted;                               
    else if (*pc != '^') s += *pc;  // Quake/Elite Force control character
    else ++pc;
    ++pc;
  }
  return s;
}

int ScanInteger(const char*& pc)
{
  bool bNeg = false;
  int i = 0;
  while (*pc && *pc == ' ') ++pc; // F�hrende Blanks �berlesen
  if (*pc == '-') 
  {
    bNeg = true;
    ++pc;
  }
  while (*pc && *pc >= '0' && *pc <= '9') // Digits
  {
    i = i * 10 + (*pc - '0');
    ++pc;
  }
  return bNeg ? -i : i;
}

int ScanHexByte(const char*& pc)
{
  int i = 0;
  for (int n = 2; n--;)
  {
    i = i * 16;
    if      (*pc >= '0' && *pc <= '9') i += *pc - '0';
    else if (*pc >= 'a' && *pc <= 'f') i += *pc - 'a' + 10;
    else if (*pc >= 'A' && *pc <= 'F') i += *pc - 'A' + 10;
    else break;
    ++pc;
  }
  return i;
}