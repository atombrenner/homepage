/****************************************************************************\
 Datei  : Scan.h
 Projekt: Pathfinder
 Inhalt : Scan helpers to parse server data
 Datum  : 17.12.2000
 Autor  : Christian Rodemeyer
 Hinweis: 
 Stempel: $Modtime: $, $Author: $, $NoKeywords: $ 
\****************************************************************************/
#pragma once

#ifndef __SCAN_H
#define __SCAN_H

CString ScanString(const char*& pc);
int ScanInteger(const char*& pc);
int ScanHexByte(const char*& pc);

#endif