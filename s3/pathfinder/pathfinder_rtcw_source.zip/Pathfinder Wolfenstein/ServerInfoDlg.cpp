// ServerInfoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Pathfinder.h"
#include "ServerInfoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerInfoDlg dialog


CServerInfoDlg::CServerInfoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerInfoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerInfoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CServerInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerInfoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CServerInfoDlg, CDialog)
	//{{AFX_MSG_MAP(CServerInfoDlg)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerInfoDlg message handlers

BOOL CServerInfoDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  SetIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME), TRUE);  

	m_tdm.SubclassDlgItem(IDC_TDM, this); 
  m_tdm.BeginDefinition();
  m_tdm.AddColDef(CStringCol(), "Variable");
  m_tdm.AddColDef(CStringCol(), "Value");
  m_tdm.EndDefinition();

  m_arranger.Create(this);
  m_arranger.Add(m_tdm, ADH_GROW|ADV_GROW);
  m_arranger.Add(IDCANCEL, ADH_MOVE|ADV_MOVE);
	
  // Daten aus GameServer kopieren
  SetWindowText(m_pGameServer->m_name);
  
  foreach (CGameServer::TVecVariables::iterator, m_pGameServer->m_variables)
  {
    CRowData& row = m_tdm.AddRow();
    row[0] = it->first;
    row[1] = it->second;
  }
  m_tdm.Sort(COrderBy(0, o_asc, -1));
  m_tdm.SetBestColWidth();
  m_tdm.LookNice();
  m_tdm.Refresh(true);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CServerInfoDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
  m_arranger.Arrange();	
}
