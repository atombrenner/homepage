/****************************************************************************\
 Datei  : GameServer.cpp
 Projekt: Pathfinder
 Inhalt : CGameServer Implementierung
 Datum  : 17.12.2000
 Autor  : Christian Rodemeyer
 Hinweis: 
 Stempel: $Modtime: $, $Author: $, $NoKeywords: $ 
\****************************************************************************/

#include "StdAfx.h"
#include "GameServer.h"
#include "Scan.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/****************************************************************************\
 CGameServer: Implementierung
\****************************************************************************/
__int64 CGameServer::m_frequency = CGameServer::GetPerformanceFrequency();

__int64 CGameServer::GetPerformanceFrequency()
{
  LARGE_INTEGER frequency;
  QueryPerformanceFrequency(&frequency);
  return frequency.QuadPart;
}

__int64 CGameServer::GetPerformanceCounter()
{
  LARGE_INTEGER counter;
  QueryPerformanceCounter(&counter);
  return counter.QuadPart;
}

CGameServer::~CGameServer()
{

}

CGameServer::CGameServer(const CSockAddr& addr, LPCSTR name, LPCSTR pwd)
{
  Reset();
  m_timeout = 1000;
  m_addr = addr;

  if (name) m_name = name;
  else      m_name = addr.GetDottedDecimalWithPort2(); // vorl�ufiger Name
  if (pwd)  m_pwd = pwd;
}

/*
void CGameServer::Query() // Queries the server asynchronly
{                                  
  if (!m_hQuery) m_hQuery = AfxBeginThread(AFX_THREADPROC(QueryThread), this)->m_hThread;
}

int CGameServer::QueryThread(CGameServer* pThis)
{
  try
  {
    CSockUDP sock;
    sock.Bind(); // Irgendeinen freien Socket nehmen
    //sock.Bind(CLocalHostInfo().GetAddr(0)); // Firewall test

    DWORD timeout = 1000;
    DWORD time = GetTickCount();
    SockCheck(sock.Send("����getstatus", 14, pThis->m_addr)); 
    pThis->Reset();
    for (int retry = 3; retry;)
    {
      if (WaitForSingleObject(sock.GetEvent(), timeout) == WAIT_TIMEOUT)
      {
        time = GetTickCount();
        sock.Send("����getstatus", 14, pThis->m_addr); 
        timeout = timeout + 500; 
        --retry;
      }
      else if (sock.GetSockEvents().IsSet(se_read))
      {
        pThis->m_ping = GetTickCount() - time;
        CString data;
        SockCheck(sock.Receive(data));
        pThis->ParseServerData(data);
        retry = 0;
      }
    }
  }
  catch (CException* pErr)
  {
    pErr->ReportError();
    pErr->Delete();
  }
  pThis->m_hQuery = NULL;
  pThis->m_pNotify->PostMessage(WM_SERVER_UPDATED, 0, LPARAM(pThis));
  return 0;
}
*/

int CGameServer::GetMsSinceLastQuery()
{
  return (GetPerformanceCounter() - m_lastQuery) * 1000 / m_frequency;
}

bool CGameServer::Query(CSockUDP& udp)
{
  if (m_nthTry == 0 || (GetMsSinceLastQuery() > m_timeout))
  {
    if (++m_nthTry <= m_maxTries) 
    {
      SockCheck(udp.Send("����getstatus", 14, m_addr)); 
      m_lastQuery = GetPerformanceCounter();
      return true;
    }
  }
  return false;
}

bool CGameServer::IsQueryDone()
{
  return (m_nthTry > m_maxTries);
}

void CGameServer::Response(const CString& data, bool bExcludeBots)
{
  if (IsQueryDone()) return;

  m_ping = GetMsSinceLastQuery();
  m_nthTry = 999;
  ParseServerData(data, bExcludeBots);
}

void CGameServer::ParseServerData(const char* pc, bool bExcludeBots)
{
  // Aufbau der zu analysierenden Daten
  // ����statusResponse<CR>
  // Liste von: \Parameter\Wert  Liste ist abgeschlossen durch <CR>
  // Liste der Spieler: Zahl Zahl "Name" <CR>

  CString Intro = "����statusResponse\n";
  pc += Intro.GetLength(); // Intro �berlesen

  while (*pc && *pc != '\n')
  {
    CString param, value;
    if (*pc == '\\') param = ScanString(++pc);
    if (*pc == '\\') value = ScanString(++pc);
    int iValue = atoi(value);

    TRACE("%s\t = %s\n", param, value);

    if      (param == "sv_hostname")   m_name = value;
    else if (param == "g_needpass")    m_bNeedsPassword = (iValue != 0);
    else if (param == "mapname")       m_map = value;
    else if (param == "sv_maxclients") m_maxPlayers = iValue;
    else if (param == "g_gametype")    m_type = iValue;
    else if (param == "g_pModElimination"    && iValue) m_mod = 1;
    else if (param == "g_pModActionHero"     && iValue) m_mod = 2;
    else if (param == "g_pModDisintegration" && iValue) m_mod = 3;
    else if (param == "g_pModAssimilation"   && iValue) m_mod = 4;
    else if (param == "g_pModSpecialties"    && iValue) m_mod = 5;
  }
  if (*pc == '\n') ++pc;

  TRACE("Players: %s\n", pc - 100);
  while (*pc) 
  {
    int frags = ScanInteger(pc); // Players frags
    int ping  = ScanInteger(pc); // Players ping

    while (*pc && *pc == ' ') ++pc; // F�hrende Blanks �berlesen
    CString player = ScanString(pc);
    if (*pc == '\n') ++pc;
    
    player.TrimLeft(); player.TrimRight();

		if (!bExcludeBots || ping > 0)
		{
      m_players.push_back(CPlayer(player, frags, ping));
		}
//    TRACE("%i\t %i\t %s\n", frags, ping, player);
  }
}

void CGameServer::Reset() // Alle Daten leeren
{
  m_nthTry = 0;
  m_timeout = 1200;
  m_ping = 999;
  m_bNeedsPassword = false;
  m_type = 0; // Not responding
  m_mod  = 0;
  m_maxPlayers = 0;
  m_players.clear();
}


