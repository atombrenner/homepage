/****************************************************************************\
 Datei  : GameServer.h
 Projekt: Pathfinder
 Inhalt : CGameServer Deklaration
 Datum  : 17.12.2000
 Autor  : Christian Rodemeyer
 Hinweis: 
 Stempel: $Modtime: $, $Author: $, $NoKeywords: $ 
\****************************************************************************/
#pragma once

#ifndef __GAMESERVER_H
#define __GAMESERVER_H

#include "Player.h"

#define WM_SERVER_UPDATED (WM_USER + 423)

/****************************************************************************\
 CGameServer: Deklaration
\****************************************************************************/
class CGameServer 
{
public:

  CGameServer() {};
  explicit CGameServer(const CSockAddr& addr, LPCSTR name = NULL, LPCSTR pwd = NULL);
  ~CGameServer();

  void Reset(); // Alle Daten leeren, auf erneute Query vorbereiten

  bool Query(CSockUDP& udp); // true, wenn Query gesendet wurde, ist auch f�r Requery zust�ndig
  void Response(const CString& data, bool bExcludeBots);
  bool IsQueryDone();
  
public:  // QD public attributes, access must be synchronized via CriticalSection
  CSockAddr m_addr;
  CString   m_name;
  CString   m_map;
  CString   m_pwd;  // can only be entered in favorites dialog
  int       m_type; // CTF, FFA, ...
  int       m_mod;
  int       m_maxPlayers;
  int       m_ping; // in ms, (-1) means no response
  bool      m_bNeedsPassword;

  std::vector<CPlayer> m_players;

private:
  __int64 m_lastQuery;
  DWORD   m_timeout;
  int     m_nthTry; // der wievielte Versuch?

  enum{ m_maxTries = 2};

  // Methods
  void ParseServerData(const char* pc, bool bExcludeBots);
  int GetMsSinceLastQuery();

  static __int64 m_frequency;
  static __int64 GetPerformanceCounter();
  static __int64 GetPerformanceFrequency();
};               


#endif 