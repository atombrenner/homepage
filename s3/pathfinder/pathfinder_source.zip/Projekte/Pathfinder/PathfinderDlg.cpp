// PathfinderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Pathfinder.h"
#include "PathfinderDlg.h"
#include "Scan.h"
#include "FavoritesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

enum EColPlayer
{
  cp_name, cp_srvPing, cp_ping, cp_frags, cp_server, cp_map, cp_players, cp_type, cp_mod,
  cp_ptr, // pointer to CGameServer
  cp_numCols
};

enum EColServer
{
  cs_name, cs_type, cs_mod, cs_ping, cs_players, cs_map, cs_password, cs_ip, 
  cs_ptr, // pointer to CGameServer
  cs_numCols
};

enum EColPlayerOnServer
{
  cpos_name, cpos_ping, cpos_frags,
  cpos_numCols
};

/////////////////////////////////////////////////////////////////////////////
// CPathfinderDlg dialog

CPathfinderDlg::CPathfinderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPathfinderDlg::IDD, pParent),
    m_gameTypes("FFA - Free for all\nDuel\nDuel\nTHM - Team Holomatch\nCTF - Capture the flag\n5?\n6?\n7?\n8?\nNot responding\n"),
    m_ctType(m_gameTypes),
    m_mods("\nElimination\nActionHero\nDisintegration\nAssimilation\nSpecialities"),
    m_ctMod(m_mods),
    m_minSize(0,0)
{
	//{{AFX_DATA_INIT(CPathfinderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
  m_hQuery = NULL;
}

CPathfinderDlg::~CPathfinderDlg()
{
  //ClearServers(); geschieht in DestroyWindow, also bevor das hWnd ung�ltig wird
}

void CPathfinderDlg::ClearServers()
{
/*
  TServerIter it = m_servers.begin();
  TServerIter end = m_servers.end();
  for (; it != end; ++it)
  {
    delete *it;
  }
*/
  m_servers.clear();        
}

void CPathfinderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPathfinderDlg)
	DDX_Control(pDX, IDC_PROGRESS, m_progress);
	DDX_Control(pDX, IDC_VIEWS, m_views);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPathfinderDlg, CDialog)
	//{{AFX_MSG_MAP(CPathfinderDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_QUERY_MASTER, OnQueryMaster)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_CBN_SELENDOK(IDC_PLAYER, OnSelendokPlayer)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_JOIN, OnJoin)
	ON_NOTIFY(TCN_SELCHANGE, IDC_VIEWS, OnSelchangeViews)
	ON_CBN_DBLCLK(IDC_PLAYER, OnDblclkPlayer)
	ON_BN_CLICKED(IDC_DEL, OnDel)
	ON_BN_CLICKED(IDC_FAVORITES, OnFavorites)
	ON_BN_CLICKED(IDC_QUERY_FAVORITES, OnQueryFavorites)
	//}}AFX_MSG_MAP
	ON_NOTIFY(NM_DBLCLK, IDC_TDM_PLAYER, OnDblclkTdmPlayer)
	ON_NOTIFY(NM_DBLCLK, IDC_TDM_SERVER, OnDblclkTdmServer)
	ON_NOTIFY(TDM_TABLECONTEXT, IDC_TDM_SERVER, OnContextTdmServer)
	ON_NOTIFY(TDM_SELCHANGED, IDC_TDM_SERVER, OnServerChanged)
  ON_MESSAGE(WM_SERVER_UPDATED, OnServerUpdated)
  ON_NOTIFY(TDM_HANDLETABLECMD, IDC_TDM_SERVER, OnHandleTdmServerCmd)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPathfinderDlg message handlers

BOOL CPathfinderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
        
  SetWindowText(AfxGetApp()->m_pszAppName);

  m_reg.SetRootKey(HKEY_CURRENT_USER);
  m_reg.SetKey("Software\\Pathfinder", true);

	// TODO: Add extra initialization here
  m_mailCR.SubclassDlgItem(IDC_MAIL_CR, this, "mailto:christian.rodemeyer@t-online.de");
  m_pathfinder.SubclassDlgItem(IDC_PATHFINDER, this, "http://home.t-online.de/home/christian.rodemeyer/pathfinder.htm");
  m_version.SubclassDlgItem(IDC_VERSION, this);
  m_speed.SubclassDlgItem(IDC_SPEED, this);
  m_player.SubclassDlgItem(IDC_PLAYER, this);
  m_player.SetAutoSelect(false);
  m_autoClose.SubclassDlgItem(IDC_AUTOCLOSE, this);
  m_password.SubclassDlgItem(IDC_PASSWORD, this);  

  DefinePlayerList();
  DefineServerList();
  DefinePlayerOnServerList();

  // Positionen berechnen
  CRect rect1, rect2;
  GetWindowRect(rect1);
  m_minSize = rect1.Size();

  m_tdmPlayer.GetWindowRect(rect1);
  m_tdmServer.GetWindowRect(rect2);
  rect2.top = rect1.top;
  ScreenToClient(rect2);
  m_tdmServer.MoveWindow(rect2);
  m_tdmPlayerOnServer.GetWindowRect(rect2);
  rect2.top = rect1.top;
  ScreenToClient(rect2);
  m_tdmPlayerOnServer.MoveWindow(rect2);
  ScreenToClient(rect1);
  rect1.bottom = rect2.bottom;
  m_tdmPlayer.MoveWindow(rect1);

  m_arranger.Create(this);

  m_split.SubclassDlgItem(IDC_SPLIT, this);
  int split = m_arranger.Add(m_split, ADV_GROW|ADH_PROP);
  m_split.Create(m_arranger, 15, 65);

  m_arranger.Add(m_views, ADH_GROW|ADV_GROW);
  m_arranger.Add(m_tdmPlayer, ADH_GROW|ADV_GROW);
  m_arranger.Add(m_tdmServer, ADH_GROW|ADV_GROW, -1, split);
  split = m_arranger.Add(m_tdmPlayerOnServer, ADH_MOVE|ADV_GROW, split); // hack for split ctrl
  m_arranger.AddArea(IDC_AREA_RIGHT, ADH_MOVE, split); // <- with -1 split ctrl will not work
  m_arranger.AddArea(IDC_AREA_RIGHT2, ADV_MOVE|ADH_MOVE, split);
  m_arranger.AddArea(IDC_AREA_BOTTOM, ADV_MOVE);
  m_arranger.Add(IDC_PROGRESS, ADV_MOVE|ADH_GROW);
  m_arranger.Add(IDC_PLAYER, ADV_GROW|ADH_MOVE);
  m_arranger.Add(IDC_SEARCH_FOR_PLAYER, ADV_GROW|ADH_MOVE);
  m_arranger.Add(IDC_SEARCH, ADV_MOVE|ADH_MOVE);
  m_arranger.Add(IDC_DEL, ADV_MOVE|ADH_MOVE);

  // TDM Einstellung aus Registry lesen
  CWordArray prop;
  HKEY hKey;
  DWORD type, size;

  m_tdmPlayer.GetSerializedProperties(prop); // setzt die Gr��e von prop richtig!
  size = prop.GetSize() * 2;
	::RegOpenKeyEx(m_reg.GetRootKey(), m_reg.GetCurrentPath(), 0, KEY_READ, &hKey);
  ::RegQueryValueEx(hKey, "TDM_Player", 0, &type, LPBYTE(prop.GetData()), &size);
  ::RegCloseKey(hKey);
  m_tdmPlayer.SetSerializedProperties(prop);
  m_tdmPlayer.Sort(m_playerOrder);
  m_tdmPlayer.Refresh(true);

  m_tdmServer.GetSerializedProperties(prop);
  size = prop.GetSize() * 2;
	::RegOpenKeyEx(m_reg.GetRootKey(), m_reg.GetCurrentPath(), 0, KEY_READ, &hKey);
  ::RegQueryValueEx(hKey, "TDM_Server", 0, &type, LPBYTE(prop.GetData()), &size);
  ::RegCloseKey(hKey);
  m_tdmServer.SetSerializedProperties(prop);
  m_tdmServer.Sort(m_serverOrder);
  m_tdmServer.Refresh(true);

  m_tdmPlayerOnServer.GetSerializedProperties(prop);
  size = prop.GetSize() * 2;
 	::RegOpenKeyEx(m_reg.GetRootKey(), m_reg.GetCurrentPath(), 0, KEY_READ, &hKey);
  ::RegQueryValueEx(hKey, "TDM_PlayerOnServer", 0, &type, LPBYTE(prop.GetData()), &size);
  ::RegCloseKey(hKey);
  m_tdmPlayerOnServer.SetSerializedProperties(prop);
  m_tdmPlayerOnServer.Refresh();

  // Spielerliste einlesen
  ReadComboList(m_player, "LastPlayers");

  // Passwordliste einlesen
  //ReadComboList(m_password, "Passwords");
  m_password = m_reg.ReadString("Password");

  CRect rect;
  if (m_reg.ReadRect("LastPos", &rect) && rect.Width() >= m_minSize.x) 
  {
    MoveWindow(rect);
    int pos = m_reg.ReadInt("SplitPos", 0);
    if (pos) m_split.SetSplitPosition(pos);
  }

  //if (m_reg.ReadInt("Version", 23) == 2) m_v10.SetCheck(1); else m_v11.SetCheck(1);
  m_version.SetCurSel(m_reg.ReadInt("Version", 24) - 22);

  m_autoClose.SetCheck(m_reg.ReadInt("AutoClose", 1));
  CheckDlgButton(IDC_EXCLUDE_BOTS, m_reg.ReadInt("ExcludeBots", BST_UNCHECKED));
  CheckDlgButton(IDC_EMPTY, m_reg.ReadInt("IncludeEmptyServers", BST_UNCHECKED));

  m_speed.SetCurSel(m_reg.ReadInt("Speed", 1));
  m_views.InsertItem(1, "Player list");
  m_views.InsertItem(2, "Server list");
  m_views.SetCurSel(m_reg.ReadInt("LastView", 0));
  OnSelchangeViews(NULL, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPathfinderDlg::ReadComboList(CComboBox& cb, const CString& regValue)
{
  CString list = m_reg.ReadString(regValue);
  int start = 0;
  while (start < list.GetLength())
  {
    int stop = list.Find('\n', start);
    if (stop == -1) stop = list.GetLength() + 1;
    cb.AddString(list.Mid(start, stop - start));
    start = stop + 1;
  }
  cb.SetCurSel(0);
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPathfinderDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPathfinderDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;   
}

void CPathfinderDlg::DefinePlayerList()   
{
  m_tdmPlayer.SubclassDlgItem(IDC_TDM_PLAYER, this);
  m_tdmPlayer.BeginDefinition(cp_numCols);

   m_tdmPlayer.SetColDef(cp_ptr,     m_ctInt); // hidden
   m_tdmPlayer.SetColDef(cp_name,    m_ctString, "Player", 120);
   m_tdmPlayer.SetColDef(cp_frags,   m_ctInt,    "Frags", 36);
   m_tdmPlayer.SetColDef(cp_ping,    m_ctInt,    "Ping", 32);
   m_tdmPlayer.SetColDef(cp_server,  m_ctString, "Server", 120);
   m_tdmPlayer.SetColDef(cp_type,    m_ctType,   "Type", 128);
   m_tdmPlayer.SetColDef(cp_mod,     m_ctMod,    "Mod", 50);
   m_tdmPlayer.SetColDef(cp_map,     m_ctString, "Map", 90);
   m_tdmPlayer.SetColDef(cp_srvPing, m_ctInt,    "ServerPing", 32);
   m_tdmPlayer.SetColDef(cp_players, m_ctString, "Players", 44);

  m_tdmPlayer.EndDefinition();

//  CWordArray prop;
//  m_tdmPlayer.SetSerializedProperties(prop);

  m_playerOrder.SetColOrder(cp_name, o_asc);
}

void CPathfinderDlg::DefineServerList()
{
  m_tdmServer.SubclassDlgItem(IDC_TDM_SERVER, this);
  m_tdmServer.BeginDefinition(cs_numCols);

   m_tdmServer.SetColDef(cs_ptr,      m_ctInt); // hidden
   m_tdmServer.SetColDef(cs_name,     m_ctString, "Server", 120);
   m_tdmServer.SetColDef(cs_ping,     m_ctInt,    "Ping", 40);
   m_tdmServer.SetColDef(cs_players,  m_ctString, "Players", 44);
   m_tdmServer.SetColDef(cs_map,      m_ctString, "Map", 90);
   m_tdmServer.SetColDef(cs_type,     m_ctType,   "Type", 128);
   m_tdmServer.SetColDef(cs_mod,      m_ctMod,    "Mod", 50);
   m_tdmServer.SetColDef(cs_password, CBoolCol(), "Password", 56);
   m_tdmServer.SetColDef(cs_ip,       m_ctString, "Ip", 200);

  m_tdmServer.EndDefinition();

  // Default Order
  m_serverOrder.SetOrder(cs_type, o_desc, cs_ping, o_asc, -1);
}

void CPathfinderDlg::DefinePlayerOnServerList()
{
  m_tdmPlayerOnServer.SubclassDlgItem(IDC_TDM_PLAYER_ON_SERVER, this);
  m_tdmPlayerOnServer.BeginDefinition(cpos_numCols);

    m_tdmPlayerOnServer.SetColDef(cpos_name,  m_ctString, "Player", 120);
    m_tdmPlayerOnServer.SetColDef(cpos_ping,  m_ctInt,    "Ping", 32);
    m_tdmPlayerOnServer.SetColDef(cpos_frags, m_ctInt,    "Frags", 36);

  m_tdmPlayerOnServer.EndDefinition();
}

void CPathfinderDlg::ParseResponse(const CString& response)
{
  //response = "����getserversResponse \\407b39d6ff40\\d57aa42b6d38\\d4066cfa6d39\\c3a64e176d39\\3e9edc246d38\\d4a2f0579448\\18437f586d38\\ca21d7176d38\\EOT";
  TRACE("Response: Len = %i\n%s\n", response.GetLength(), response.Left(400));

  if (response.GetLength() >= 24)
  {
    const char* pc = LPCSTR(response) + 24;
    for (CString value = ScanString(pc); !value.IsEmpty() && value != "EOT"; value = ScanString(pc))
    {
      CSockAddr addr;

      const char* pHexByte = value;
      addr.sin_addr.S_un.S_un_b.s_b1 = ScanHexByte(pHexByte);
      addr.sin_addr.S_un.S_un_b.s_b2 = ScanHexByte(pHexByte);
      addr.sin_addr.S_un.S_un_b.s_b3 = ScanHexByte(pHexByte);
      addr.sin_addr.S_un.S_un_b.s_b4 = ScanHexByte(pHexByte);

      int hi = ScanHexByte(pHexByte);
      int lo =  ScanHexByte(pHexByte);
      addr.SetPort(hi * 256 + lo);
      if (*pc == '\\') ++pc;

      m_servers[addr] = CGameServer(addr);

      //m_servers[addr].Init(this, addr);  
      //TRACE("Server: %s\n", addr.GetDottedDecimalWithPort2());
    }
  }
}

void CPathfinderDlg::OnQueryFavorites() 
{
  CWaitCursor wc;

  if (m_hQuery) // query in progress
  {
    m_stopQuery.Set();
    if (WaitForSingleObject(m_hQuery, 5000) == WAIT_TIMEOUT) return;
  } 

  m_bExcludeBots         = IsDlgButtonChecked(IDC_EXCLUDE_BOTS) != 0;
	m_bIncludeEmptyServers = IsDlgButtonChecked(IDC_EMPTY) != 0;

  LoadFavorites();
	OnQueryServers();
}

void CPathfinderDlg::OnQueryMaster() 
{
  CWaitCursor wc;

  if (m_hQuery) // query in progress
  {
    m_stopQuery.Set();
    if (WaitForSingleObject(m_hQuery, 5000) == WAIT_TIMEOUT) return;
  }
  m_bExcludeBots         = IsDlgButtonChecked(IDC_EXCLUDE_BOTS) != 0;
	m_bIncludeEmptyServers = IsDlgButtonChecked(IDC_EMPTY) != 0;

  // contact master server for server list
  CSockAddr master("204.97.248.66:27953"); // master.stef1.ravensoft.com
  //CSockAddr master("master.stef1.ravensoft.com:27953");  
  //CSockAddr master("master.gamespy.com:27900");
  CSockUDP sock;
  sock.Bind(); // irgend einen freien Socket nehmen
  //sock.Bind(CLocalHostInfo().GetAddr(0)); // firewall test

  // build master query
  //CString masterQuery = "����getservers 23"; // Dahinter kann der Spieltyp ctf etc kommen
  // version = 21; ??
  // version = 22; Original v1.0
  // version = 23; Patch 1.1
  // version = 24; Patch 1.2 / Expansion Pack
  int version = m_version.GetCurSel() + 22;

  CString query; // "����getservers %i empty full demo\n"
  query.Format("����getservers %i %sfull\n", version, m_bIncludeEmptyServers ? "empty ": ""); 
  int retry = 3;
  int timeout = 800;
  while (retry)
  {
    SockCheck(sock.Send(query, master));
    if (WaitForSingleObject(sock.GetEvent(), timeout) == WAIT_TIMEOUT)
    {
      --retry;
      timeout += 500;
    }
    else if (sock.GetSockEvents().IsSet(se_read))
    {
      break;
    }
  }
  if (!retry)
  {
    if (AfxMessageBox("No response from master server. Query last known servers?", MB_YESNO|MB_ICONQUESTION) == IDNO) return;
    LoadServer();    
  }
  else
  {
    ClearServers();

    CString response;
    SockCheck(sock.Receive(response));

    //response = "����getserversResponse \\407b39d6ff40\\d57aa42b6d38\\d4066cfa6d39\\c3a64e176d39\\3e9edc246d38\\d4a2f0579448\\18437f586d38\\ca21d7176d38\\EOT";
    ParseResponse(response);

    while (WaitForSingleObject(sock.GetEvent(), timeout) != WAIT_TIMEOUT)
    {
      if (sock.GetSockEvents().IsSet(se_read))
      {
        SockCheck(sock.Receive(response));
        ParseResponse(response);
      }
    }
  }
  OnQueryServers(); // query every single server
}

void CPathfinderDlg::QueryServers()
{
  int parallel = 1 << m_speed.GetCurSel(); // Maximale Anzahl paralleler Anfragen

  CTimer    timer(200); // 200ms Timer
  CString   data;
  CSockAddr from;
  CSockUDP  udp;
  udp.Bind();

  std::vector<CGameServer*> pendingQueries;
  TServerIter nextQuery = m_servers.begin();

  HANDLE objects[] = {m_stopQuery, udp.GetEvent(), timer};
  for (;;)
  {
    DWORD obj = WaitForMultipleObjects(3, objects, false, INFINITE);

    if (obj == WAIT_OBJECT_0) break;

    // Response
    if (obj == (WAIT_OBJECT_0 + 1) && udp.GetSockEvents().IsSet(se_read))
    {
      udp.Receive(data, from);
      TServerIter server = m_servers.find(from);
      if (server != m_servers.end()) server->second.Response(data, m_bExcludeBots);
      TRACE("Response from: %s\n", from.GetDottedDecimalWithPort2());
    }

    // Query
    if (obj == WAIT_OBJECT_0 + 2)
    {
      // Abbruch, wenn alle Server untersucht worden sind
      if (nextQuery == m_servers.end() && pendingQueries.size() == 0) break;

      // Pending Queries untersuchen 
      int sends = 0;
      std::vector<CGameServer*>::iterator it = pendingQueries.begin();
      while (it != pendingQueries.end())
      {
        if ((*it)->Query(udp)) 
        {
          ++sends;
        }
        if ((*it)->IsQueryDone())
        {
          PostMessage(WM_SERVER_UPDATED, 0, LPARAM(*it));
          it = pendingQueries.erase(it);
        }
        else ++it;
      }

      // Neue Queries losschicken
      while (nextQuery != m_servers.end() && sends < parallel)
      {
        nextQuery->second.Query(udp);
        ++sends;
        pendingQueries.push_back(&nextQuery->second);
        ++nextQuery;
      }
    }
  }
}

UINT CPathfinderDlg::ThreadQueryServers(CPathfinderDlg* pThis)
{
  pThis->QueryServers();
  pThis->m_hQuery = NULL;
  return 0;
}

void CPathfinderDlg::OnQueryServers() 
{
	if (!m_hQuery) 
  {
    m_stopQuery.Reset();

    m_playerOrder = m_tdmPlayer.GetOrderBy();
    m_tdmPlayer.DeleteAllRows(); 
    m_tdmPlayer.Refresh(true);

    m_serverOrder = m_tdmServer.GetOrderBy();
    m_tdmServer.DeleteAllRows(); 
    m_tdmServer.Refresh(true);

    m_tdmPlayerOnServer.DeleteAllRows(); 
    m_tdmPlayerOnServer.Refresh(true);

    foreach (TServerIter, m_servers)
    {
      it->second.Reset();
    }
    m_serversToQuery = m_servers.size();
    SetDlgItemInt(IDC_TO_QUERY, m_serversToQuery);
		SetDlgItemInt(IDC_NUM_SERVERS, 0);
    SetDlgItemInt(IDC_NUM_PLAYERS, 0);
    m_progress.SetRange(0, m_serversToQuery);
    m_progress.SetPos(0);
    m_hQuery = AfxBeginThread(AFX_THREADPROC(ThreadQueryServers), this)->m_hThread;
  }
}

void CPathfinderDlg::OnDestroy() 
{
  if (m_hQuery)
  {
    m_stopQuery.Set();
    WaitForSingleObject(m_hQuery, INFINITE);
  }
  ClearServers(); // wartet indirekt auf auf noch offende GameServerThreads

  WriteComboList(m_player, "LastPlayers");
  //WriteComboList(m_password, "Password");
  m_reg.WriteString("Password", m_password.AsString());

  m_reg.WriteInt("AutoClose", m_autoClose.GetCheck());
  m_reg.WriteInt("ExcludeBots", IsDlgButtonChecked(IDC_EXCLUDE_BOTS));
  m_reg.WriteInt("IncludeEmptyServers", IsDlgButtonChecked(IDC_EMPTY));

  // TDM Einstellung in Registry sichern (Key muss existieren)
  CWordArray prop;
  HKEY hKey;

  m_tdmPlayer.GetSerializedProperties(prop);
	::RegOpenKeyEx(m_reg.GetRootKey(), m_reg.GetCurrentPath(), 0, KEY_ALL_ACCESS, &hKey);
  ::RegSetValueEx(hKey, "TDM_Player", 0, REG_BINARY, reinterpret_cast<unsigned char*>(prop.GetData()), prop.GetSize() * 2);
  ::RegCloseKey(hKey);
  //TraceTDM(m_tdmPlayer);
  
  m_tdmServer.GetSerializedProperties(prop);
	::RegOpenKeyEx(m_reg.GetRootKey(), m_reg.GetCurrentPath(), 0, KEY_ALL_ACCESS, &hKey);
  ::RegSetValueEx(hKey, "TDM_Server", 0, REG_BINARY, reinterpret_cast<unsigned char*>(prop.GetData()), prop.GetSize() * 2);
  ::RegCloseKey(hKey);
  //TraceTDM(m_tdmServer);

  m_tdmPlayerOnServer.GetSerializedProperties(prop);
 	::RegOpenKeyEx(m_reg.GetRootKey(), m_reg.GetCurrentPath(), 0, KEY_ALL_ACCESS, &hKey);
  ::RegSetValueEx(hKey, "TDM_PlayerOnServer", 0, REG_BINARY, reinterpret_cast<unsigned char*>(prop.GetData()), prop.GetSize() * 2);
  ::RegCloseKey(hKey);
  //TraceTDM(m_tdmPlayerOnServer);

  CRect rect;
  GetWindowRect(rect);
  rect.NormalizeRect();
  m_reg.WriteRect("LastPos", &rect);
  m_reg.WriteInt("SplitPos", m_split.GetSplitPosition());
  m_reg.WriteInt("Speed", m_speed.GetCurSel());
  m_reg.WriteInt("Version", m_version.GetCurSel() + 22);
  m_reg.WriteInt("LastView", m_views.GetCurSel());

	CDialog::OnDestroy();
}

void CPathfinderDlg::WriteComboList(CComboBox& cb, const CString& regValue)
{
  CString s, list;
  for (int i = cb.GetCount(); i--;)
  { 
    cb.GetLBText(i, s);
    list += s + "\n";        
  }
  m_reg.WriteString(regValue, list); // legt Schl�ssel implizit an
}

void CPathfinderDlg::AddServerToView(const CGameServer* pServer)
{
  int numPlayers = pServer->m_players.size();
  CString nom;
  nom.Format("%i/%i", numPlayers, pServer->m_maxPlayers);

  CRowData& row = m_tdmServer.AddRow();
  row[cs_name]     = pServer->m_name;
  row[cs_ping]     = pServer->m_ping;
  row[cs_password] = pServer->m_bNeedsPassword;
  row[cs_players]  = nom;
  row[cs_type]     = pServer->m_type;
  row[cs_mod]      = pServer->m_mod;
  row[cs_map]      = pServer->m_map;
  row[cs_ip]       = pServer->m_addr.GetDottedDecimalWithPort2();
  row[cs_ptr]      = reinterpret_cast<int>(pServer);

  for (int i = numPlayers; i--;)
  {
    CRowData& row = m_tdmPlayer.AddRow();
    row[cp_name]    = pServer->m_players[i].m_name;
    row[cp_ping]    = pServer->m_players[i].m_ping;
    row[cp_frags]   = pServer->m_players[i].m_frags;
    row[cp_server]  = pServer->m_name;
    row[cp_type]    = pServer->m_type;
    row[cp_mod]     = pServer->m_mod;
    row[cp_map]     = pServer->m_map;
    row[cp_srvPing] = pServer->m_ping;
    row[cp_players] = nom;
    row[cp_ptr]     = reinterpret_cast<int>(pServer);
  }
  m_tdmPlayer.SetBestColWidth(true);
  m_tdmPlayer.Sort(m_playerOrder);
  m_tdmPlayer.Refresh(true);

  m_tdmServer.Sort(m_serverOrder);
  m_tdmServer.Refresh(true);
}

LRESULT CPathfinderDlg::OnServerUpdated(WPARAM, LPARAM lpGameServer)
{
	CGameServer* pServer = reinterpret_cast<CGameServer*>(lpGameServer);

	if (m_bIncludeEmptyServers || pServer->m_players.size() > 0)
	{
    AddServerToView(pServer);
    SetDlgItemInt(IDC_NUM_PLAYERS, m_tdmPlayer.GetNumRows());
		SetDlgItemInt(IDC_NUM_SERVERS, m_tdmServer.GetNumRows());
	}

	SetDlgItemInt(IDC_TO_QUERY, --m_serversToQuery);
  m_progress.OffsetPos(1);
  if (!m_serversToQuery) 
  {
    m_progress.SetPos(0);
    SaveServer(); // Server Datei schreiben
  }
  return 0;
}

void CPathfinderDlg::OnServerChanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
  NMTableCtrl* pNM = reinterpret_cast<NMTableCtrl*>(pNMHDR);
  // Selektion eine Gameservers hat sich ge�ndert
  FillPlayerOnServer(pNM->iRow);
	*pResult = 0;
}

void CPathfinderDlg::FillPlayerOnServer(int iRow)
{
  COrderBy orderBy = m_tdmPlayerOnServer.GetOrderBy();
  m_tdmPlayerOnServer.DeleteAllRows();
  if (m_tdmServer.IsRowValid(iRow))
  {
    const CGameServer* pServer = reinterpret_cast<const CGameServer*>(m_tdmServer[iRow][cs_ptr].AsInt());
    for (int i = pServer->m_players.size(); i--;)
    {
      CRowData& row = m_tdmPlayerOnServer.AddRow();
      row[cpos_name]  = pServer->m_players[i].m_name;
      row[cpos_ping]  = pServer->m_players[i].m_ping;
      row[cpos_frags] = pServer->m_players[i].m_frags;
    }
    m_tdmPlayerOnServer.Sort(orderBy);
  }
  m_tdmPlayerOnServer.Refresh(true);
}

void CPathfinderDlg::OnSearch() 
{
  CString player;
  m_player.GetWindowText(player);
  SearchPlayer(player);
}

void CPathfinderDlg::SearchPlayer(CString player)
{
  player.TrimLeft(); player.TrimRight();
  if (player.IsEmpty()) return;
  TRACE("SearchPlayer: %s\n", player);

  // wenn noch nicht in der Liste aufgenommen, jetzt aufnehmen
  if (m_player.FindStringExact(0, player) == CB_ERR)
  {
    m_player.SetCurSel(m_player.AddStringWithData(player, 1)); // als neu markieren
  }

  // Player Eintrag suchen und markieren
  bool bContains = false;
  int iPlayerRow = -1;
  if (player[0] == '*')
  {
    bContains = true;
    player = player.Right(player.GetLength() - 1);
  }
  player.MakeUpper();
  m_tdmPlayer.Sort(COrderBy(cp_name, o_asc, -1));
  for (int iRow = 0, iRowMax = m_tdmPlayer.GetNumRows(); iRow < iRowMax; ++iRow)
  {
    CString name = m_tdmPlayer[iRow][cp_name].AsString();
    name.MakeUpper();
    int i = name.Find(player);
    if (i == 0 || (i > 0 && bContains))
    {
      m_tdmPlayer.MoveRow(iRow, 0);
      iPlayerRow = 0;
    }
  }
  m_tdmPlayer.Refresh();

  // Player Eintrag suchen und markieren
/*
  int iPlayerRow = m_tdmPlayer.Find(cp_name, CDString(player), 0);
  if (!m_tdmPlayer.IsRowValid(iPlayerRow))
  {
    m_tdmPlayer.Sort(COrderBy(cp_name, o_asc, -1));
    m_tdmPlayer.Refresh(true);
    for (iPlayerRow = 0; iPlayerRow < m_tdmPlayer.GetNumRows(); ++iPlayerRow)
    {                                                         
      if (player.CompareNoCase(m_tdmPlayer[iPlayerRow][cp_name].AsString().Left(player.GetLength())) == 0) 
        break;
    }
  }
  */

  if (m_tdmPlayer.IsRowValid(iPlayerRow))
  {
    m_tdmPlayer.SetCurSel(iPlayerRow);
    m_tdmPlayer.ScrollIntoView(iPlayerRow);
    m_tdmPlayer.Refresh(true);
    // Server Eintrag markieren
    int iServerRow = m_tdmServer.Find(cs_ptr, m_tdmPlayer[iPlayerRow][cp_ptr], 0);
    if (m_tdmServer.IsRowValid(iServerRow))
    {
      m_tdmServer.SetCurSel(iServerRow); 
      m_tdmServer.ScrollIntoView(iServerRow);
      m_tdmServer.Refresh(true);
      FillPlayerOnServer(iServerRow);
      int iRow = m_tdmPlayerOnServer.Find(cpos_name, m_tdmPlayer[iPlayerRow][cp_name]);
      m_tdmPlayerOnServer.SetCurSel(iRow);
      m_tdmPlayerOnServer.Refresh();
    }
    else ASSERT(false);
  }
}

void CPathfinderDlg::OnSize(UINT nType, int cx, int cy) 
{
	//CDialog::OnSize(nType, cx, cy);
	m_arranger.Arrange();
}

void CPathfinderDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	CDialog::OnGetMinMaxInfo(lpMMI);
  if (m_minSize.x && m_minSize.y) lpMMI->ptMinTrackSize = m_minSize;
}

void CPathfinderDlg::OnJoin() 
{                                                             
  const CGameServer* pServer = NULL;

  if (m_views.GetCurSel() == 0) // Playerlist
  {
    int iRow = m_tdmPlayer.GetCurSel();
    if (m_tdmPlayer.IsRowValid(iRow))
    {
      pServer = reinterpret_cast<const CGameServer*>(m_tdmPlayer[iRow][cp_ptr].AsInt());
    }
    else return;
  }
  else // Serverlist
  {
    int iRow = m_tdmServer.GetCurSel();
    if (m_tdmServer.IsRowValid(iRow))
    {
      pServer = reinterpret_cast<const CGameServer*>(m_tdmServer[iRow][cs_ptr].AsInt());
    }
    else return;
  }
  if (!pServer) return;

  m_stopQuery.Set();
  CString stvoy = m_reg.ReadString("STVOY");
  CString params;

  if (pServer->m_bNeedsPassword)
  {
    CString pwd;
    m_password.GetWindowText(pwd);
    pwd.TrimLeft(); pwd.TrimRight();

    if (pwd.IsEmpty() && pServer->m_pwd.IsEmpty())
    {
      AfxMessageBox("This server needs a password.");
      return;
    }
    if (pwd != pServer->m_pwd && !pwd.IsEmpty() && !pServer->m_pwd.IsEmpty())
    {
      CString msg;
      msg.Format("Ambiguous passwords! Use the favorite one (%s)?", pServer->m_pwd);
      int ret = AfxMessageBox(msg, MB_YESNOCANCEL);
      if (ret == IDCANCEL) return;
      if (ret == IDYES) pwd = pServer->m_pwd;
    }
    params.Format(" connect \"%s\"; password \"%s\"", pServer->m_addr.GetDottedDecimalWithPort2(), pwd);
  }
  else
  {
    params.Format(" connect %s", pServer->m_addr.GetDottedDecimalWithPort2());
  }

  SetCurrentDirectory(stvoy.Left(stvoy.ReverseFind('\\')));
  while (WinExec(stvoy + params, SW_NORMAL) <= 31)
  {
    CFileDialog dlg(true, NULL, "stvoyHM.exe", OFN_HIDEREADONLY, "*.exe|*.exe||");
    if (dlg.DoModal() != IDOK) return; // Cancel
    stvoy = dlg.GetPathName();
    m_reg.WriteString("STVOY", stvoy);
    SetCurrentDirectory(stvoy.Left(stvoy.ReverseFind('\\')));
  }
  if (m_autoClose.GetCheck()) OnCancel(); // terminate gracefully
}

void CPathfinderDlg::OnSelchangeViews(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (m_views.GetCurSel() == 0) // Player list
  {
    m_split.ShowWindow(SW_HIDE);
    m_tdmServer.ShowWindow(SW_HIDE);
    m_tdmPlayerOnServer.ShowWindow(SW_HIDE);
    m_tdmPlayer.ShowWindow(SW_SHOW);
  }
  else // Server list
  {
    m_tdmPlayer.ShowWindow(SW_HIDE);
    m_tdmServer.ShowWindow(SW_SHOW);
    m_tdmPlayerOnServer.ShowWindow(SW_SHOW);
    m_split.ShowWindow(SW_SHOW);
  }
}

static NextDblClk = 0;

void CPathfinderDlg::OnSelendokPlayer() 
{
  NextDblClk = GetTickCount() + 100;
	SearchPlayer(m_player.GetCurSelString());
}

void CPathfinderDlg::OnDblclkPlayer() 
{
  // UltraQD Hack: ignore message if lastmessage is too young
  if (GetTickCount() > NextDblClk)
  {
    CString player;
    m_player.GetWindowText(player);
    SearchPlayer(player);
  }
}

CString CPathfinderDlg::GetServerFile()
{ 
  switch (m_version.GetCurSel())
  {
  case 0: return "v10.dat";
  case 1: return "v11.dat";
  case 2: return "v12.dat";
  default: return "";
  }
}

void CPathfinderDlg::SaveServer() // update file with server addr
{
  typedef std::set<CSockAddr>  TSetServer;
  typedef TSetServer::iterator TSetServerIter;

  TSetServer servers;
  CStdioFile file;

  // Vorhandenes File auslesen
  if (file.Open(GetServerFile(), CFile::modeRead))
  {
    for (CString s; file.ReadString(s);) 
    {
      servers.insert(CSockAddr(s));
    }
    file.Close();
  }

  // mit aktuellen Servern vereinigen
  for (TServerIter it = m_servers.begin(), end = m_servers.end(); it != end; ++it)
  {
    servers.insert(it->first);
  }
  
  // und Ergebnismenge abspeichern
  if (file.Open(GetServerFile(), CFile::modeWrite|CFile::modeCreate))
  {
    for (TSetServerIter it = servers.begin(), end = servers.end(); it != end; ++it)
    {
      file.WriteString(it->GetDottedDecimalWithPort2());
      file.WriteString("\n");
    }
  }
}

void CPathfinderDlg::LoadServer() // read servers from file
{
  ClearServers();

  CStdioFile file;
  if (file.Open(GetServerFile(), CFile::modeRead))
  {
    for (CString s; file.ReadString(s);)
    {
      CSockAddr addr(s);
      m_servers[addr] = CGameServer(addr); 
    }
  }
}

void CPathfinderDlg::LoadFavorites() 
{
  ClearServers();

  CStdioFile file;
  if (file.Open("favorites.dat", CFile::modeRead))
  {
    for (CExString s; file.ReadString(s);)
    {
      CSockAddr addr(s.GetField('\t', 0));
      m_servers[addr] = CGameServer(addr, s.GetField('\t', 1), s.GetField('\t', 2)); 
    }
  }
}

void CPathfinderDlg::OnDel() 
{
	int item = m_player.GetCurSel(); 
  if (item != CB_ERR)
  {
    CString msg;
    msg.Format("Are you sure to delete '%s'?", m_player.GetCurSelString());
    if (AfxMessageBox(msg, MB_YESNO|MB_ICONQUESTION) == IDYES)
    {
      m_player.DeleteString(item);
    }
  }
}

void CPathfinderDlg::OnFavorites() 
{
	CFavoritesDlg().DoModal();
}

void CPathfinderDlg::OnDblclkTdmServer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnJoin();
	*pResult = 0;
}

void CPathfinderDlg::OnDblclkTdmPlayer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnJoin();
	*pResult = 0;
}

void CPathfinderDlg::OnContextTdmServer(NMHDR* pNMHDR, LRESULT* pResult) 
{
  NMTableCtrl* pNM = Cast_NMTableCtrl(pNMHDR); // relativ sicherer Cast
  LPCSTR favMenu = "~Add to favorites;-";

  if (m_tdmServer.IsRowValid(pNM->iRow)) 
  {
    // if (!m_tdmServer[pNM->iRow][cs_ip].AsString() is in favorites)
    ++favMenu;
  }

  pNM->pMenu->Insert(0, favMenu, TDMC_ROOT - 1, MF_BYPOSITION);
	*pResult = 0;
}

void CPathfinderDlg::OnHandleTdmServerCmd(NMHDR* pNMHDR, LRESULT* pResult)
{
  NMTableCtrl* pNM = Cast_NMTableCtrl(pNMHDR); // relativ sicherer Cast

  if (pNM->nCmd == TDMC_ROOT - 1) // Add to favorites
  {
    CStdioFile file("favorites.dat", CFile::modeReadWrite|CFile::modeCreate|CFile::modeNoTruncate);
    
    CExString ip = m_tdmServer[pNM->iRow][cs_ip].AsString();
    for (CExString s; file.ReadString(s);)
    {
      if (s.GetField('\t', 0) == ip) return; // is already favorite
    }
    CExString name = m_tdmServer[pNM->iRow][cs_name].AsString();
    name.Replace('\t', ' ');
    name.Trim();
    file.WriteString(m_tdmServer[pNM->iRow][cs_ip].AsString() + "\t" + name + "\t\n");

    *pResult = 1; // TDM soll diesen Befehl nicht behandeln
  }
  else *pResult = 0; // das TDM soll die Defaultaktion durchf�hren
}
