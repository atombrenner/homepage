// PathfinderDlg.h : header file
//

#if !defined(AFX_PATHFINDERDLG_H__AAD7EE87_D341_11D4_A947_E54029B00D49__INCLUDED_)
#define AFX_PATHFINDERDLG_H__AAD7EE87_D341_11D4_A947_E54029B00D49__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPathfinderDlg dialog


#include "GameServer.h"

class CPathfinderDlg : public CDialog
{
// Construction
public:
  CPathfinderDlg(CWnd* pParent = NULL); // standard constructor
  ~CPathfinderDlg();

  CHyperLink  m_mailCR;
  CHyperLink  m_pathfinder;
  CTableCtrl  m_tdmPlayer;
  CTableCtrl  m_tdmServer;
  CTableCtrl  m_tdmPlayerOnServer;
  CExComboBox m_version;
  CButton     m_autoClose;
  CExComboBox m_speed;
  CExComboBox m_player;
  CExEdit     m_password;
  CSplitCtrl  m_split;
  CArranger   m_arranger;
  CPoint      m_minSize;

  // TDM ColTypes
  CEnum      m_gameTypes; // Enum for TDM
  CEnumCol   m_ctType;    // gametype enumeration
  CEnum      m_mods;      // Enum for TDM
  CEnumCol   m_ctMod;     // mod enumeration (ActionHero, Assimilation, ...
  CStringCol m_ctString;  // generic string
  CIntCol    m_ctInt;     // generic int

  // Query parameters
  int        m_serversToQuery;
  CAutoEvent m_stopQuery; // Zum Abbrechen der Query
  HANDLE     m_hQuery;    // Thread Handle f�r QueryServers
	bool       m_bExcludeBots;
	bool       m_bIncludeEmptyServers;

  // Game servers
  typedef std::map<CSockAddr, CGameServer> TServerMap;
  typedef TServerMap::iterator             TServerIter;
  TServerMap m_servers;

  // Persistente TDM Sortierung
  COrderBy m_playerOrder;
  COrderBy m_serverOrder;

  CRegistry m_reg;

  // Methods
  void ClearServers();
  void AddServerToView(const CGameServer* pServer);
  void FillPlayerOnServer(int iRow);
  void SearchPlayer(CString player);

  void DefinePlayerList();
  void DefineServerList();
  void DefinePlayerOnServerList();

  void ReadComboList(CComboBox& cb, const CString& regValue);
  void WriteComboList(CComboBox& cb, const CString& regValue);

  static UINT ThreadQueryServers(CPathfinderDlg* pThis);
  void QueryServers();
  void ParseResponse(const CString& response);

  // Serverliste sichern
  CString GetServerFile();
  void SaveServer(); // update file with server addr
  void LoadServer(); // read servers from file
  void LoadFavorites(); // read servers from favorites.dat

// Dialog Data
  //{{AFX_DATA(CPathfinderDlg)
  enum { IDD = IDD_PATHFINDER_DIALOG };
  CProgressCtrl m_progress;
  CTabCtrl  m_views;
  //}}AFX_DATA

  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CPathfinderDlg)
  protected:
  virtual void DoDataExchange(CDataExchange* pDX);  // DDX/DDV support
  //}}AFX_VIRTUAL

// Implementation
protected:
  HICON m_hIcon;

	void OnQueryServers();

  // Generated message map functions
  //{{AFX_MSG(CPathfinderDlg)
  virtual BOOL OnInitDialog();
  afx_msg void OnPaint();
  afx_msg HCURSOR OnQueryDragIcon();
  afx_msg void OnQueryMaster();
  afx_msg void OnDestroy();
  afx_msg void OnSearch();
  afx_msg void OnSelendokPlayer();
  afx_msg void OnSize(UINT nType, int cx, int cy);
  afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
  afx_msg void OnJoin();
  afx_msg void OnSelchangeViews(NMHDR* pNMHDR, LRESULT* pResult);
  afx_msg void OnDblclkPlayer();
  afx_msg void OnDel();
	afx_msg void OnFavorites();
	afx_msg void OnQueryFavorites();
	//}}AFX_MSG
  afx_msg void OnServerChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkTdmServer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkTdmPlayer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnContextTdmServer(NMHDR* pNMHDR, LRESULT* pResult);
  afx_msg LRESULT OnServerUpdated(WPARAM, LPARAM pGameServer);
  afx_msg void OnHandleTdmServerCmd(NMHDR* pNMHDR, LRESULT* pResult);
  DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PATHFINDERDLG_H__AAD7EE87_D341_11D4_A947_E54029B00D49__INCLUDED_)
