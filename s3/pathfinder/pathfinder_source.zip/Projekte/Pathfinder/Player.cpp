/****************************************************************************\
 Datei  : Player.cpp
 Projekt: Pathfinder
 Inhalt : CPlayer Implementierung
 Datum  : 18.12.2000
 Autor  : Christian Rodemeyer
 Hinweis: 
 Stempel: $Modtime: $, $Author: $, $NoKeywords: $ 
\****************************************************************************/

#include "StdAfx.h"
#include "Player.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/****************************************************************************\
 CPlayer: Implementierung
\****************************************************************************/


 