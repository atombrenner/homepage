/****************************************************************************\
 Datei  : Player.h
 Projekt: Pathfinder
 Inhalt : CPlayer Deklaration
 Datum  : 18.12.2000
 Autor  : Christian Rodemeyer
 Hinweis: 
 Stempel: $Modtime: $, $Author: $, $NoKeywords: $ 
\****************************************************************************/
#pragma once

#ifndef __PLAYER_H
#define __PLAYER_H


/****************************************************************************\
 CPlayer: Deklaration
\****************************************************************************/
class CPlayer
{
public:
  CPlayer() {};
  CPlayer(const CString& name, int frags, int ping): m_name(name), m_frags(frags), m_ping(ping) {}

  CString m_name;
  int     m_frags;
  int     m_ping;
};


#endif 