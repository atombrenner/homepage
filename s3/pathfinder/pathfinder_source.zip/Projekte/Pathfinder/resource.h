//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Pathfinder.rc
//
#define IDD_PATHFINDER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_FAVORITES                   131
#define IDC_QUERY_MASTER                1004
#define IDC_QUERY                       1005
#define IDC_LIST1                       1009
#define IDC_TDM_PLAYER_ON_SERVER        1009
#define IDC_COMBO1                      1010
#define IDC_PLAYER                      1010
#define IDC_TDM_PLAYERS                 1011
#define IDC_TDM_PLAYER                  1011
#define IDC_TDM_SERVER                  1012
#define IDC_RADIO2                      1015
#define IDC_RADIO3                      1016
#define IDC_TO_QUERY                    1017
#define IDC_BUTTON1                     1018
#define IDC_JOIN                        1018
#define IDC_ADD                         1018
#define IDC_BUTTON2                     1019
#define IDC_SEARCH                      1019
#define IDC_DELETE                      1019
#define IDC_MAIL_CR                     1020
#define IDC_NUM_PLAYERS                 1021
#define IDC_EMPTY                       1022
#define IDC_VIEWS                       1023
#define IDC_SPEED                       1024
#define IDC_PROGRESS                    1025
#define IDC_UPDATE                      1026
#define IDC_NUM_SERVERS                 1027
#define IDC_AREA_RIGHT                  1028
#define IDC_AREA_BOTTOM                 1029
#define IDC_SPLIT                       1030
#define IDC_AREA_RIGHT2                 1031
#define IDC_DEL                         1032
#define IDC_PATHFINDER                  1033
#define IDC_EXCLUDE_BOTS                1034
#define IDC_SEARCH_FOR_PLAYER           1035
#define IDC_VERSION                     1036
#define IDC_AUTOCLOSE                   1037
#define IDC_PASSWORD                    1041
#define IDC_QUERY_FAVORITES             1042
#define IDC_FAVORITES                   1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
